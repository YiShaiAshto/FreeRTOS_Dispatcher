/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "semphr.h"
#include "task.h"
#include "queue.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct Data{
	size_t discription;
	size_t amount;
} Data;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
Data *Data_ISR;
char * unit[] = {"Police","Fire","Ambulance", "Corona"};

enum discription{Police = 0, Fire, Ambulance, Corona};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART3_UART_Init(void);
void StartDefaultTask(void *argument);

/* USER CODE BEGIN PFP */
static void DispacherDepartment( void *pvParameters );

static void PoliceDepartment(void *pvParameters);
static void Police_vehicle1(void *pvParameters);
static void Police_vehicle2(void *pvParameters);
static void Police_vehicle3(void *pvParameters);

static void FireDepartment(void *pvParameters);
static void Fire_vehicle1(void *pvParameters);
static void Fire_vehicle2(void *pvParameters);
static void Fire_vehicle3(void *pvParameters);

static void AmbulanceDepartment(void *pvParameters);
static void Ambulance_vehicle1(void *pvParameters);
static void Ambulance_vehicle2(void *pvParameters);
static void Ambulance_vehicle3(void *pvParameters);
static void Ambulance_vehicle4(void *pvParameters);

static void CoronaDepartment(void *pvParameters);
static void Corona_vehicle1(void *pvParameters);
static void Corona_vehicle2(void *pvParameters);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
BaseType_t status;

// TASKS HANDLES
TaskHandle_t dispacher_handler;
TaskHandle_t police_handler;
TaskHandle_t fire_handler;
TaskHandle_t ambulance_handler;
TaskHandle_t corona_handler;

// QUEUE HANDLES
QueueHandle_t DataQueue;
QueueHandle_t PoliceQueue;
QueueHandle_t FireQueue;
QueueHandle_t AmbulanceQueue;
QueueHandle_t CoronaQueue;

// SEMAPHORE HANDLES
SemaphoreHandle_t xCountingSemaphorePolice;
SemaphoreHandle_t xCountingSemaphoreFire;
SemaphoreHandle_t xCountingSemaphoreAmbulance;
SemaphoreHandle_t xCountingSemaphoreCorona;
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  xCountingSemaphorePolice = xSemaphoreCreateCounting(13 , 0);
    xCountingSemaphoreFire = xSemaphoreCreateCounting(13 , 0);
    xCountingSemaphoreAmbulance = xSemaphoreCreateCounting(13 , 0);
    xCountingSemaphoreCorona = xSemaphoreCreateCounting(13 , 0);
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
    DataQueue = xQueueCreate(1, sizeof(Data *));
      if(DataQueue == NULL) printf("DataQueue not created");
      PoliceQueue = xQueueCreate(3, sizeof(Data *));
      if(PoliceQueue == NULL) printf("PoliceQueue not created");
      FireQueue = xQueueCreate(3, sizeof(Data *));
      if(FireQueue == NULL) printf("FireQueue not created");
      AmbulanceQueue = xQueueCreate(3, sizeof(Data *));
      if(AmbulanceQueue == NULL) printf("AmbulanceQueue not created");
      CoronaQueue =  xQueueCreate(3, sizeof(Data *));
      if(CoronaQueue == NULL) printf("CoronaQueue not created");
  /* USER CODE END RTOS_QUEUES */

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
      status = xTaskCreate(DispacherDepartment, "Dispatcher", 250, NULL, 5, &dispacher_handler);
        configASSERT(status == pdPASS);

        status = xTaskCreate(PoliceDepartment, "Police", 150, NULL, 3, &police_handler);
        configASSERT(status == pdPASS);
        status = xTaskCreate(Police_vehicle1, "P1", 150, NULL, 4, NULL );
        configASSERT(status == pdPASS);
        status = xTaskCreate(Police_vehicle2, "P2", 150, NULL, 4, NULL );
        configASSERT(status == pdPASS);
        status = xTaskCreate(Police_vehicle3, "P3", 150, NULL, 4, NULL );
        configASSERT(status == pdPASS);


        status = xTaskCreate(FireDepartment, "Fire", 150, NULL, 3, &fire_handler);
        configASSERT(status == pdPASS);
        status = xTaskCreate(Fire_vehicle1, "F1", 150, NULL, 4, NULL );
        configASSERT(status == pdPASS);
        status = xTaskCreate(Fire_vehicle2, "F2", 150, NULL, 4, NULL );
        configASSERT(status == pdPASS);
        status = xTaskCreate(Fire_vehicle3, "F3", 150, NULL, 4, NULL );
        configASSERT(status == pdPASS);

        status = xTaskCreate(AmbulanceDepartment, "Ambulance", 150, NULL, 3, &ambulance_handler);
        configASSERT(status == pdPASS);
        status = xTaskCreate(Ambulance_vehicle1, "A1", 150, NULL, 4, NULL );
        configASSERT(status == pdPASS);
        status = xTaskCreate(Ambulance_vehicle2, "A2", 150, NULL, 4, NULL );
        configASSERT(status == pdPASS);
        status = xTaskCreate(Ambulance_vehicle3, "A3", 150, NULL, 4, NULL );
        configASSERT(status == pdPASS);
        status = xTaskCreate(Ambulance_vehicle4, "A4", 150, NULL, 2, NULL );
        configASSERT(status == pdPASS);

        status = xTaskCreate(CoronaDepartment, "Corona", 150, NULL, 3, &corona_handler);
        configASSERT(status == pdPASS);
        status = xTaskCreate(Corona_vehicle1, "C1", 150, NULL, 4, NULL );
        configASSERT(status == pdPASS);
        status = xTaskCreate(Corona_vehicle2, "C2", 150, NULL, 4, NULL );
        configASSERT(status == pdPASS);
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 72;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 3;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LD1_Pin|LD3_Pin|LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(USB_PowerSwitchOn_GPIO_Port, USB_PowerSwitchOn_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : USER_Btn_Pin */
  GPIO_InitStruct.Pin = USER_Btn_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(USER_Btn_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : RMII_MDC_Pin RMII_RXD0_Pin RMII_RXD1_Pin */
  GPIO_InitStruct.Pin = RMII_MDC_Pin|RMII_RXD0_Pin|RMII_RXD1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF11_ETH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : RMII_REF_CLK_Pin RMII_MDIO_Pin RMII_CRS_DV_Pin */
  GPIO_InitStruct.Pin = RMII_REF_CLK_Pin|RMII_MDIO_Pin|RMII_CRS_DV_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF11_ETH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LD1_Pin LD3_Pin LD2_Pin */
  GPIO_InitStruct.Pin = LD1_Pin|LD3_Pin|LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : RMII_TXD1_Pin */
  GPIO_InitStruct.Pin = RMII_TXD1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF11_ETH;
  HAL_GPIO_Init(RMII_TXD1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : USB_PowerSwitchOn_Pin */
  GPIO_InitStruct.Pin = USB_PowerSwitchOn_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(USB_PowerSwitchOn_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : USB_OverCurrent_Pin */
  GPIO_InitStruct.Pin = USB_OverCurrent_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(USB_OverCurrent_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : USB_SOF_Pin USB_ID_Pin USB_DM_Pin USB_DP_Pin */
  GPIO_InitStruct.Pin = USB_SOF_Pin|USB_ID_Pin|USB_DM_Pin|USB_DP_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF10_OTG_FS;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : USB_VBUS_Pin */
  GPIO_InitStruct.Pin = USB_VBUS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(USB_VBUS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : RMII_TX_EN_Pin RMII_TXD0_Pin */
  GPIO_InitStruct.Pin = RMII_TX_EN_Pin|RMII_TXD0_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF11_ETH;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin_13)
{
	// This is the button interrupt callback.
	// It generate randomly  Police/Fire/Ambulance or Corona department.
	// Then it randomly (MAX 5) choose amount of vehicles(units).
	// Then send the info via "DataQueue".
	Data_ISR->discription = rand() % 4;
	Data_ISR->amount = rand() % 7;
	printf("Button interrupt.\n\r"); // for debugging only.
	xQueueSendToBackFromISR(DataQueue, &Data_ISR, NULL);
}

static void DispacherDepartment(void *pvParameters)
{
	Data* buffer_d;
	for( ;; )
	{
		// Receiving info from button interrupt via "buffer_d".
		// Then compare the info to the right task and pass the info forward via
		// "CoronaQueue"/"AmbulanceQueue"/"FireQueue"/"PoliceQueue"
		// to the next task (Police, Fire, Ambulance or Corona).
		if(xQueueReceive(DataQueue, &buffer_d, portMAX_DELAY) == pdPASS){
			printf("Main Dispatcher Department.\n\r");
			switch (buffer_d->discription) {
				case Police:
					xQueueSendToBack(PoliceQueue, &buffer_d, 0);
					break;
				case Fire:
					xQueueSendToBack(FireQueue, &buffer_d, 0);
					break;
				case Ambulance:
				    xQueueSendToBack(AmbulanceQueue, &buffer_d, 0);
					break;
				case Corona:
					xQueueSendToBack(CoronaQueue, &buffer_d, 0);
					break;
				default:
					printf("Invalid description/department !");
					break;
			}
			printf("Sending message to %s department.\n\r", unit[buffer_d->discription]);
		}
		else
			printf("DataQueue receive timeout.");
	}
}



//------------------------------------------------------
//						POLICE FUNCTIONS
//------------------------------------------------------

static void PoliceDepartment( void *pvParameters )
{
	Data * buffer_p;
	size_t amount_p = 0;
	for(;;)
	{
		// Receiving info from "Dispatcher" using the "buffer_p" buffer
		// via PoliceQueue, and process the amount vehicles needed and
		// the "Police" task giving the counting semaphore "xCountingSemaphorePolice"
		// the amount times needed.
		if(xQueueReceive(PoliceQueue, &buffer_p, portMAX_DELAY) == pdPASS){
			amount_p = buffer_p->amount;
			printf("Main Police Department: ");
			printf("Sending %d police vehicles.\n\r", buffer_p->amount);
			for (size_t i = 0; i < amount_p ; ++i) {
				xSemaphoreGive(xCountingSemaphorePolice);
				  vTaskSwitchContext();
			}
		}
		else
			printf("PoliceQueue receive timeout.");

	}
}

static void Police_vehicle1(void *pvParameters){
	for(;;){
		// Receiving counting semaphore "xCountingSemaphorePolice"
		// from "Police" task.
		if(xSemaphoreTake(xCountingSemaphorePolice, portMAX_DELAY) == pdTRUE){
			vTaskDelay(pdMS_TO_TICKS(rand() % 30));
			printf("Police vehicle #1 finished job.\n\r");
		}
		else
			printf("Police vehicle #1 Semaphore timeout.");
	}
}
static void Police_vehicle2(void *pvParameters){
	for(;;){
		if(xSemaphoreTake(xCountingSemaphorePolice, portMAX_DELAY) == pdTRUE){
			vTaskDelay(pdMS_TO_TICKS(rand() % 30));
			printf("Police vehicle #2 finished job.\n\r");
		}
		else
			printf("Police vehicle #2  Semaphore timeout.");
	}
}
static void Police_vehicle3(void *pvParameters){
	for(;;){
		if(xSemaphoreTake(xCountingSemaphorePolice, portMAX_DELAY) == pdTRUE){
			vTaskDelay(pdMS_TO_TICKS(rand() % 30));
			printf("Police vehicle #3 finished job.\n\r");
		}
		else
			printf("Police vehicle #3  Semaphore timeout.");
	}
}

//------------------------------------------------------
//						FIRE FUNCTIONS
//------------------------------------------------------

static void FireDepartment(void *pvParameters){
	Data * buffer_f;
	size_t amount_f = 0;
	for(;;){
		if(xQueueReceive(FireQueue, &buffer_f, portMAX_DELAY) == pdPASS){
			amount_f = buffer_f->amount;
			printf("Main Fire Department: ");
			printf("Sending %d fire vehicles.\n\r", buffer_f->amount);
			for (size_t i = 0; i < amount_f ; ++i) {
				xSemaphoreGive(xCountingSemaphoreFire);
				  vTaskSwitchContext();
			}
		}
		else
			printf("FireQueue receive timeout.");
	}
}

static void Fire_vehicle1(void *pvParameters){
	for(;;){
		if(xSemaphoreTake(xCountingSemaphoreFire, portMAX_DELAY) == pdTRUE){
			vTaskDelay(pdMS_TO_TICKS(rand() % 30));
			printf("Fire vehicle #1 finished job.\n\r");
		}
		else
			printf("Fire vehicle #1 Semaphore timeout.");
	}
}
static void Fire_vehicle2(void *pvParameters){
	for(;;){
		if(xSemaphoreTake(xCountingSemaphoreFire, portMAX_DELAY) == pdTRUE){
			vTaskDelay(pdMS_TO_TICKS(rand() % 30));
			printf("Fire vehicle #2 finished job.\n\r");
		}
		else
			printf("Fire vehicle #2 Semaphore timeout.");
	}
}
static void Fire_vehicle3(void *pvParameters){
	for(;;){
		if(xSemaphoreTake(xCountingSemaphoreFire, portMAX_DELAY) == pdTRUE){
			vTaskDelay(pdMS_TO_TICKS(rand() % 30));
			printf("Fire vehicle #3 finished job.\n\r");
		}
		else
			printf("Fire vehicle #3 Semaphore timeout.");
	}
}

//------------------------------------------------------
//						AMBULANCE FUNCTIONS
//------------------------------------------------------

static void AmbulanceDepartment(void *pvParameters){
	Data * buffer_a;
	size_t amount_a = 0;
	for(;;){
		if(xQueueReceive(AmbulanceQueue, &buffer_a, portMAX_DELAY) == pdPASS){
			amount_a = buffer_a->amount;
			printf("Main Ambulance Department: ");
			printf("Sending %d ambulance vehicles.\n\r", buffer_a->amount);
			for (size_t i = 0; i < amount_a ; ++i) {
				xSemaphoreGive(xCountingSemaphoreAmbulance);
				  vTaskSwitchContext();

			}
		}
		else
			printf("AmbulanceQueue receive timeout.");	}
}

static void Ambulance_vehicle1(void *pvParameters){
	for(;;){
		if(xSemaphoreTake(xCountingSemaphoreAmbulance, portMAX_DELAY) == pdTRUE){
			vTaskDelay(pdMS_TO_TICKS(rand() % 30));
			printf("Ambulance vehicle #1 finished job.\n\r");
		}
		else
			printf("Ambulance vehicle #1 Semaphore timeout.");
	}
}
static void Ambulance_vehicle2(void *pvParameters){
	for(;;){
		if(xSemaphoreTake(xCountingSemaphoreAmbulance, portMAX_DELAY) == pdTRUE){
			vTaskDelay(pdMS_TO_TICKS(rand() % 30));
			printf("Ambulance vehicle #2 finished job.\n\r");
		}
		else
			printf("Ambulance vehicle #2 Semaphore timeout.");
	}
}
static void Ambulance_vehicle3(void *pvParameters){
	for(;;){
		if(xSemaphoreTake(xCountingSemaphoreAmbulance, portMAX_DELAY) == pdTRUE){
			vTaskDelay(pdMS_TO_TICKS(rand() % 30));
			printf("Ambulance vehicle #3 finished job.\n\r");
		}
		else
			printf("Ambulance vehicle #3 Semaphore timeout.");
	}
}
static void Ambulance_vehicle4(void *pvParameters){
	for(;;){
		if(xSemaphoreTake(xCountingSemaphoreAmbulance, portMAX_DELAY) == pdTRUE){
			vTaskDelay(pdMS_TO_TICKS(rand() % 30));
			printf("Ambulance vehicle #4 finished job.\n\r");
		}
		else
			printf("Ambulance vehicle #4 Semaphore timeout.");
	}
}

//------------------------------------------------------
//						CORONA FUNCTIONS
//------------------------------------------------------

static void CoronaDepartment(void *pvParameters){
	Data * buffer_c;
	size_t amount_c = 0;
	for(;;){
		if(xQueueReceive(CoronaQueue, &buffer_c, portMAX_DELAY) == pdPASS){
			amount_c = buffer_c->amount;
			printf("Main Corona Department: ");
			printf("Sending %d corona vehicles\n\r", buffer_c->amount);
			for (size_t i = 0; i < amount_c ; ++i) {
				xSemaphoreGive(xCountingSemaphoreCorona);
				  vTaskSwitchContext();

			}
		}
		else
			printf("CoronaQueue receive timeout.");
	}
}

static void Corona_vehicle1(void *pvParameters){
	for(;;){
		if(xSemaphoreTake(xCountingSemaphoreCorona, portMAX_DELAY) == pdTRUE){
			vTaskDelay(pdMS_TO_TICKS(rand() % 30));
			printf("Corona vehicle #1 finished job.\n\r");
		}
		else
			printf("Corona vehicle #1 Semaphore timeout.\n\r");
	}
}
static void Corona_vehicle2(void *pvParameters){
	for(;;){
		if(xSemaphoreTake(xCountingSemaphoreCorona, portMAX_DELAY) == pdTRUE){
			vTaskDelay(pdMS_TO_TICKS(rand() % 30));
			printf("Corona vehicle #2 finished job.\n\r");
		}
		else
			printf("Corona vehicle #2 Semaphore timeout.\n\r");
	}
}
/* USER CODE END 4 */


/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

